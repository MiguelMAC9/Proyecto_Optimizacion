This is a simple example package. You can use
[GitHub-flavored Markdown](https://github.com/MiguelMAC9/Proyecto_Optimizacion)
to write your content.